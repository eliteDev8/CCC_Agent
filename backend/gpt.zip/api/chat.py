from fastapi import APIRouter, Depends, HTTPException
from backend.schemas.chat import AgentChatResponse, AgentChatRequest, ChatMessageSchema
from backend.services.chat_service import handle_user_message
from backend.database import get_db_session
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload
from typing import List, Any

from backend.models.chat import ChatMessage
from backend.models.session import Session

from backend.dependencies.auth import get_current_user
from backend.models.user import User  # this is the user model

router = APIRouter(prefix="/chat", tags=["Chat"])

@router.post("/agent/respond", response_model=AgentChatResponse)
async def respond_to_user(
    req: AgentChatRequest,
    db: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(get_current_user)  # Assuming you have a dependency to get the current user
):
    reply = await handle_user_message(req.session_id, req.message, db)
    return AgentChatResponse(response=reply)


@router.get("/history/{user_id}/{agent_id}", response_model=List[ChatMessageSchema])
async def get_chat_history(user_id: int, agent_id: int, db: AsyncSession = Depends(get_db_session)):
    # Get sessions by user and agent
    session_result = await db.execute(
        select(Session.session_id).where(Session.user_id == user_id, Session.agent_id == agent_id)
    )
    session_ids = [row[0] for row in session_result.all()]

    # if not session_ids:
    #     raise HTTPException(status_code=404, detail="No sessions found for this user and agent.")

    # # Get chat messages for those sessions
    chat_result = await db.execute(
        select(ChatMessage).where(ChatMessage.session_id.in_(session_ids))
    )
    return chat_result.scalars().all() 