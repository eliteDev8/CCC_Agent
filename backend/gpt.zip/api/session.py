from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from typing import List

from backend.database import get_db_session
from backend.models.session import Session
from backend.schemas.session import SessionSummary


router = APIRouter(prefix="/sessions", tags=["Sessions"])
@router.get("/user/{user_id}", response_model=List[SessionSummary])
async def get_user_sessions(user_id: int, db: AsyncSession = Depends(get_db_session)):
    result = await db.execute(
        select(Session).where(Session.user_id == user_id).order_by(Session.created_at.desc())
    )
    return result.scalars().all()
