from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from backend.database import get_db_session
from backend.models.token_usage import TokenUsage
from sqlalchemy.future import select

router = APIRouter(prefix="/usage", tags=["Usage"])

@router.get("/user/{user_id}")
async def get_user_usage(user_id: int, db: AsyncSession = Depends(get_db_session)):
    result = await db.execute(select(TokenUsage).where(TokenUsage.user_id == user_id))
    return result.scalars().all()

@router.get("/daily-summary/{user_id}")
async def get_daily_summary(user_id: int, db: AsyncSession = Depends(get_db_session)):
    from sqlalchemy import func
    result = await db.execute(
        select(
            func.date(TokenUsage.created_at).label("date"),
            func.sum(TokenUsage.total_tokens).label("tokens"),
            func.sum(TokenUsage.cost).label("cost")
        )
        .where(TokenUsage.user_id == user_id)
        .group_by(func.date(TokenUsage.created_at))
        .order_by(func.date(TokenUsage.created_at).desc())
    )
    return [dict(r._mapping) for r in result.fetchall()]