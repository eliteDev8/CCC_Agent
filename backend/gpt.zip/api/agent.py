from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from backend.database import get_db_session
from backend.engines.session_manager import SessionManager
from backend.models.user import User
from backend.engines.data_source_engine.controller import DataSourceController
import redis.asyncio as redis
import asyncio
import os
import json
from backend.schemas.agent import AgentCreate, AgentUpdate, AgentRead
from backend.models.agent import Agent
from backend.models.session import Session

from sqlalchemy import update, delete, select

router = APIRouter(prefix="/agent", tags=["Agent"])

# Setup redis connection using environment variables
redis_client: redis.Redis = redis.Redis(
    host=os.getenv("REDIS_HOST", "redis"),
    port=int(os.getenv("REDIS_PORT", 6379)),
    decode_responses=True
)
session_manager = SessionManager(redis_client, get_db_session)
controller = DataSourceController()

### --------------------
### 1. Start Session
### --------------------

class StartSessionRequest(BaseModel):
    user_id: int
    agent_key: int

@router.post("/start-session")
async def start_session(
    req: StartSessionRequest,
    db: AsyncSession = Depends(get_db_session),
):
    session_manager = SessionManager(redis_client, db)
    session_id = await session_manager.create_session(req.user_id, req.agent_key)
    return {"session_id": session_id}


### --------------------
### 2. Activate Agent
### --------------------

class ActivateAgentRequest(BaseModel):
    session_id: str

@router.post("/activate")
async def activate_agent(
    req: ActivateAgentRequest,
    db: AsyncSession = Depends(get_db_session), 
):
    # session_manager = SessionManager(redis_client, db)
    # session = await session_manager.get_session(req.session_id)
    # if session:
    #     return session


    result = await db.execute(select(Session).where(Session.session_id == req.session_id))
    session_result = result.scalar_one_or_none()

    if not session_result:
        return {"error": f"Agent ID  not found"}

    agent_id = session_result.agent_id
    agent_data =await controller.build_agent_profile(agent_id)
    if not agent_data:
        raise HTTPException(status_code=404, detail="Agent profile not found")

    return {
        "agent_key": agent_id,
        "agent_profile": agent_data
    }


### --------------------                                        
### 3. Trigger Flow from JSON
### --------------------

class FlowRequest(BaseModel):
    template_name: str

@router.post("/flow")
def trigger_conversational_flow(req: FlowRequest):
    import json
    import os

    path = f"backend/Agents/energy_coach/conversational_flows/{req.template_name}.json"
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Flow not found")

    with open(path, "r", encoding="utf-8") as f:
        flow = json.load(f)

    return {"template": req.template_name, "steps": flow}



@router.post("/", response_model=AgentRead)
async def create_agent(data: AgentCreate,db: AsyncSession = Depends(get_db_session)):
    # Check if agent with the same name already exists
    existing = await db.execute(select(Agent).where(Agent.name == data.name))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Agent with this name already exists")

    agent = Agent(name=data.name, role=data.role)
    db.add(agent)
    await db.commit()
    await db.refresh(agent)
    return agent


@router.get("/{agent_id}", response_model=AgentRead)
async def get_agent(agent_id: int, db: AsyncSession = Depends(get_db_session)):
    result = await db.execute(select(Agent).where(Agent.id == agent_id))
    return result.scalar_one_or_none()


@router.get("/", response_model=list[AgentRead])
async def get_all_agents(db: AsyncSession = Depends(get_db_session)):
    result = await db.execute(select(Agent))
    return result.scalars().all()

@router.put("/{agent_id}", response_model=AgentRead)
async def update_agent(agent_id: int, data: AgentUpdate, db: AsyncSession = Depends(get_db_session)):
    if data.name:
        existing = await db.execute(select(Agent).where(Agent.id == agent_id))
        if not existing.scalar_one_or_none():
            raise HTTPException(status_code=400, detail="Agent not found")

    stmt = update(Agent).where(Agent.id == agent_id).values(**data.dict(exclude_unset=True)).execution_options(synchronize_session="fetch")
    await db.execute(stmt)
    await db.commit()
    return await get_agent(agent_id,db)

@router.delete("/{agent_id}")
async def delete_agent(agent_id: int,db: AsyncSession = Depends(get_db_session)):
    result = await db.execute(select(Agent).where(Agent.id == agent_id))
    agent = result.scalar_one_or_none()

    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    await db.delete(agent)
    await db.commit()
    return {"detail": "Agent deleted successfully"}