from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from backend.dependencies.auth import get_db_session
from backend.schemas.user import UserCreate, UserLogin, UserOut
from backend.services.auth_service import register_user, authenticate_user, create_token_for_user, getUserData
from typing import Any


router = APIRouter(prefix="/auth", tags=["Auth"])

@router.post("/register", response_model=UserOut)
async def register(data: UserCreate, db: AsyncSession = Depends(get_db_session)):
    try:
        user = await register_user(data, db)
        return user
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/login")
async def login(data: UserLogin, db: AsyncSession = Depends(get_db_session)):
    user = await authenticate_user(data.email, data.password, db)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = await create_token_for_user(user)
    return {"access_token": token, "token_type": "bearer"}

@router.post("/user", response_model=UserOut)
async def getUser(data: UserLogin, db: AsyncSession = Depends(get_db_session)):
    try:
        user = await getUserData(data.email, db)
        return user
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))