from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from backend.database import get_db_session

from backend.schemas.user_json_field import JSONFieldChange
from backend.services.user_service import (
    handle_json_field, update_json_array
)

router = APIRouter(prefix="/user/domain", tags=["RAM Field"])

FIELD_NAME = "domain"

@router.post("/add")
async def add_ram_item(data: JSONFieldChange, db: AsyncSession = Depends(get_db_session)):
    user, items = await handle_json_field(data.user_id, FIELD_NAME, db)
    updated_items = update_json_array(items, data.key, data.value, "add")
    setattr(user, FIELD_NAME, updated_items)
    print(updated_items)
    await db.commit()
    await db.refresh(user)
    return updated_items


@router.post("/update")
async def update_ram_item(data: JSONFieldChange, db: AsyncSession = Depends(get_db_session)):
    user, items = await handle_json_field(data.user_id, FIELD_NAME, db)
    updated_items = update_json_array(items, data.key, data.value, "update")
    setattr(user, FIELD_NAME, updated_items)
    await db.commit()
    await db.refresh(user)
    return items



@router.post("/delete")
async def delete_ram_item(data: JSONFieldChange, db: AsyncSession = Depends(get_db_session)):
    user, items = await handle_json_field(data.user_id, FIELD_NAME, db)
    updated_items = update_json_array(items, data.key, None, "delete")
    setattr(user, FIELD_NAME, updated_items)
    await db.commit()
    await db.refresh(user)
    return updated_items
