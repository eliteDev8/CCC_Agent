# services/session_manager.py
from typing import Optional
import uuid
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from backend.models.agent import Agent
from backend.engines.data_source_engine.controller import DataSourceController
import json

from backend.models.session import Session

class SessionManager:
    def __init__(self, redis, db: AsyncSession):
        self.redis = redis 
        self.db = db

    async def create_session(self, user_id: int, agent_key: Optional[int] = None) -> str:
        session_id = str(uuid.uuid4())
        agent_key = agent_key or 1

        # agent = await self._load_agent(agent_key)
        controller = DataSourceController()
        agent_profile =await controller.build_agent_profile(agent_key)

        agent_profile = {
            "system_prompt": agent_profile.get("system_prompt", ""),
            "domain_knowledge": agent_profile.get("domain_knowledge", ""),
            "flows": json.dumps(agent_profile.get("flows", [])),
            "source_materials": json.dumps(agent_profile.get("source_materials", [])),
        }

        session_data = {
            "user_id": str(user_id),
            "agent_id": str(agent_key),
            "agent_key": "energy_coach",
            **agent_profile
        }

        await self.redis.hset(session_id, mapping=session_data)

        new_session = Session(
                session_id=session_id,
                user_id=user_id,
                agent_id=agent_key
            )
        self.db.add(new_session)
        await self.db.commit()

        return session_id

    async def get_session(self, session_id: str) -> Optional[dict]:
        result = await self.db.execute(select(Session).where(Session.session_id == session_id))
        session_result = result.scalar_one_or_none()
        return {
            "user_id": session_result.user_id if session_result else None,
            "agent_key": session_result.agent_id if session_result else None,
        }

    async def _load_agent(self, id: str) -> Agent:
        result = await self.db.execute(select(Agent).where(Agent.id == id))
        agent = result.scalar_one_or_none()
        if not agent:
            raise ValueError(f"Agent '{id}' not found")
        return agent
