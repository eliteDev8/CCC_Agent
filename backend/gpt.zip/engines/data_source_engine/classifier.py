from typing import Dict, Any

class Classifier:
    def classify(self, parsed_data: Dict[str, Any], file_path: str) -> Dict[str, Any]:
        tags = []
        if "flow" in file_path:
            tags.append("protocol")
        if "prompt" in file_path or "system_prompt" in file_path:
            tags.append("static_prompt")
        if file_path.endswith(".pdf") or file_path.endswith(".md"):
            tags.append("embed")

        return {
            "file_path": file_path,
            "tags": tags,
            "data": parsed_data
        }
