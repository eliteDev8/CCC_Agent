import os
from typing import List

class Scanner:
    SUPPORTED_EXTENSIONS = [".txt", ".md", ".json", ".pdf"]

    def __init__(self, root_dir: str):
        self.root_dir = root_dir

    def scan(self) -> List[str]:
        found_files = []
        for dirpath, _, filenames in os.walk(self.root_dir):
            for f in filenames:
                if any(f.endswith(ext) for ext in self.SUPPORTED_EXTENSIONS):
                    found_files.append(os.path.join(dirpath, f))
        return found_files
