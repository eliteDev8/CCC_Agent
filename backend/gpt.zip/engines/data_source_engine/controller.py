import os
from backend.engines.data_source_engine.scanner import Scanner
from backend.engines.data_source_engine.parser import Parser
from backend.engines.data_source_engine.classifier import Classifier
from backend.engines.data_source_engine.router import Router

from sqlalchemy.ext.asyncio import AsyncSession
from backend.database import get_db_session
import logging
from backend.models.agent import Agent
from fastapi import Depends, APIRouter

from sqlalchemy import update, delete, select
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DataSourceController:
    def __init__(self, agent_root: str = "Agents"):
        self.agent_root = agent_root

    async def build_agent_profile(self, agent: int) -> dict:
        db_gen = get_db_session()
        db = await anext(db_gen)
        try:
            current_dir = os.path.dirname(os.path.abspath(__file__))

            result = await db.execute(select(Agent).where(Agent.id == agent))
            agent_result = result.scalar_one_or_none()

            if not agent_result:
                return {"error": f"Agent ID {agent} not found"}

            agent_name = agent_result.name
            logger.info(f"AgentName: {agent_name}")

            agent_path = os.path.abspath(os.path.join(current_dir, "..", "..", self.agent_root , agent_name))
            if not os.path.exists(agent_path):
                return {
                    "agent":agent_path
                }
            logger.info(f"AgentName:{agent_name}")

            scanner = Scanner(agent_path)
            parser = Parser()
            classifier = Classifier()
            router = Router()

            all_files = scanner.scan()

            # logger.info(f"all_files:{all_files}")
            system_prompt = ""
            domain_knowledge = ""
            flows = []
            sources = []

            for file_path in all_files:
                parsed = parser.parse(file_path)
                classified = classifier.classify(parsed, file_path)
                destination = router.route(classified)

                if destination == "PromptComposer" and "system_prompt" in file_path:
                    system_prompt = parsed
                elif "domain_knowledge.md" in file_path:
                    domain_knowledge = parsed
                elif destination == "ProtocolEngine":
                    flows.append(parsed)
                elif destination == "EmbeddingHandler":
                    sources.append(parsed)

            return {
                "agent_key": agent,
                "system_prompt": system_prompt,
                "domain_knowledge": domain_knowledge,
                "flows": flows,
                "source_materials": sources
            }
        finally:
            await db_gen.aclose()
