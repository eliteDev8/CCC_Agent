from typing import Dict

class Router:
    def route(self, classified_data: Dict) -> str:
        tags = classified_data.get("tags", [])

        if "embed" in tags:
            return "EmbeddingHandler"
        if "protocol" in tags:
            return "ProtocolEngine"
        if "static_prompt" in tags:
            return "PromptComposer"

        return "UnknownEngine"
