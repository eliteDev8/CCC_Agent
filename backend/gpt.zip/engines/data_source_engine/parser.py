import json
import os
from typing import Union
import PyPDF2

class Parser:
    def parse(self, file_path: str) -> Union[str, dict, None]:
        try:
            if file_path.endswith(".json"):
                with open(file_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            elif file_path.endswith(".txt") or file_path.endswith(".md"):
                with open(file_path, "r", encoding="utf-8") as f:
                    return f.read()
            elif file_path.endswith(".pdf"):
                with open(file_path, "rb") as f:
                    reader = PyPDF2.PdfReader(f)
                    return "\n".join([page.extract_text() for page in reader.pages if page.extract_text()])
        except Exception as e:
            print(f"[Parse Error] {file_path}: {e}")
            return None