import weaviate
from weaviate.collections.classes.filters import Filter
from weaviate.collections.classes.config import CollectionConfig
from weaviate.collections.classes.config import Property
from openai import OpenAI

class EmbeddingHandler:
    def __init__(self):
        self.client = None
        self.memory_collection = None
        self.openai = None

    async def init(self):
        # Connect to Weaviate (assumes schema is ready)
        self.client = weaviate.connect_to_local(host="weaviate", port=8080, skip_init_checks=True)

        if "Memory" not in self.client.collections.list_all():
                    self.client.collections.create(
                        name="Memory",
                        config=CollectionConfig(
                            vectorizer_config="none",
                            properties=[
                                Property(name="user_id", data_type="string"),
                                Property(name="message", data_type="text")
                            ]
                        )
                    )
        self.memory_collection = self.client.collections.get("Memory")
        self.openai = OpenAI(api_key="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")
        return self

    def _get_embedding(self, text: str):
        response = self.openai.embeddings.create(
            input=[text],
            model="text-embedding-ada-002"
        )
        return response.data[0].embedding

    def embed_and_store(self, user_id: str, text: str):
        embedding = self._get_embedding(text)
        self.memory_collection.data.insert(
            properties={
                "user_id": user_id,
                "message": text
            },
            vector=embedding
        )

    def search(self, user_id: str, query: str):
        user_id = str(user_id)
        vector = self._get_embedding(query)
        filters = Filter.by_property("user_id").equal(user_id)
        results = self.memory_collection.query.near_vector(
            near_vector=vector,
            limit=3,
            filters=filters
        )
        return [obj.properties["message"] for obj in results.objects]

    def shutdown(self):
        if self.client:
            self.client.close()
