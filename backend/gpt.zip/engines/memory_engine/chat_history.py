import uuid
from backend.models.chat import ChatMessage
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from backend.database import get_db_session
class ChatLogger:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def log(self, session_id: str, message: str, sender: str, timestamp):
        chat = ChatMessage(
            id=str(uuid.uuid4()),
            session_id=session_id,
            sender=sender,
            message=message,
            timestamp=timestamp
        )
        self.db.add(chat)
        await self.db.commit()

    async def get_history(self, session_id: str):
        result = await self.db.execute(select(ChatMessage).where(ChatMessage.session_id == session_id))
        messages = result.scalars().all()
        return [{"sender": m.sender, "message": m.message, "timestamp": m.timestamp.isoformat()} for m in messages]
