from backend.engines.data_source_engine.controller import DataSourceController



def format_user_blueprint(blueprint: dict) -> str:
    lines = ["👤 USER BLUEPRINT", "--------------------"]

    if blueprint.get("ram"):
        lines.append("🧠 RAM (important beliefs, goals, mental state):")
        lines.append(str(blueprint["ram"]))

    if blueprint.get("domain"):
        lines.append("🌐 DOMAIN (life areas like Work, Health, Relationships):")
        lines.append(str(blueprint["domain"]))

    if blueprint.get("client_data"):
        lines.append("📋 CLIENT DATA (personal background, traits, needs):")
        lines.append(str(blueprint["client_data"]))

    return "\n".join(lines) if len(lines) > 2 else ""  # only return if something was added


class PromptComposer:
    async def compose(self, agent_key, message, chat_history, memory, user_blueprint=None):
        controller = DataSourceController()
        agent_profile = await controller.build_agent_profile(agent_key)

        memory_context = "\n".join(memory or [])
        base_prompt = "\n".join(agent_profile or [])
        history_text = "\n".join([f"{msg['sender']}: {msg['message']}" for msg in chat_history or []])

        blueprint_section = format_user_blueprint(user_blueprint or {})
        # Build a full composed prompt that integrates memory and history if needed
        composed_prompt = f"""
{base_prompt}

{blueprint_section}

📚 Previous relevant context:
{memory_context}

💬 Conversation history:
{history_text}

📝 User's current message:
{message}

🎯 Please respond based on the context, history, and the user's blueprint.
Here mention about recent message and current message.
"""
        return composed_prompt
