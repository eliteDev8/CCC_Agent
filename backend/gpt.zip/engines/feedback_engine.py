class FeedbackEngine:
    def __init__(self):
        self.db = {}  # Replace with real DB

    async def submit_feedback(self, user_id, session_id, rating, comment):
        self.db.setdefault(user_id, []).append({
            "session_id": session_id,
            "rating": rating,
            "comment": comment
        })
        return True
