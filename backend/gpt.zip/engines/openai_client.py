import os
from openai import AsyncOpenAI

class OpenAIClient:
    def __init__(self):
        self.client = AsyncOpenAI(api_key="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")

    async def get_response(self, prompt: str) -> str:
        response = await self.client.chat.completions.create(
            model="gpt-4o", # or "gpt-4-turbo"
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt}
                    ]
                }
            ],
            temperature=0.7
        )
        return response
