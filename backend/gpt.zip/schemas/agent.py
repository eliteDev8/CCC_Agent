from pydantic import BaseModel

class AgentCreate(BaseModel):
    name: str
    role: str

class AgentUpdate(BaseModel):
    name: str | None = None
    role: str | None = None

class AgentRead(BaseModel):
    id: int
    name: str
    role: str

    class Config:
        orm_mode = True
