from pydantic import BaseModel, Field
from datetime import datetime

class SessionSummary(BaseModel):
    session_id: str = Field(..., description="Session ID")
    user_id: int = Field(..., description="User ID")
    agent_id: int = Field(..., description="Agent ID")
    created_at: datetime = Field(..., description="Creation timestamp")

    class Config:
        orm_mode = True
