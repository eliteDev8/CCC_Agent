from pydantic import BaseModel
from typing import Optional

class JSONFieldChange(BaseModel):
    user_id: int
    key: str
    value: Optional[str] = None