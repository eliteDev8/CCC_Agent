from pydantic import BaseModel, Field
from datetime import datetime
class AgentChatRequest(BaseModel):
    session_id: str = Field(..., description="Unique identifier for the chat session")
    message: str = Field(..., description="Message content to be sent in the chat")

class AgentChatResponse(BaseModel):
    response: str = Field(..., description="Response from the agent to the chat message")


class ChatMessageSchema(BaseModel):
    session_id: str
    sender: str
    message: str
    timestamp: datetime

    class Config:
        orm_mode = True