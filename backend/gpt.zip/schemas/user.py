from pydantic import BaseModel, EmailStr
from pydantic import ConfigDict
from typing import Optional, List, Any
class UserCreate(BaseModel):
    email: EmailStr
    password: str
    full_name: str | None = None

class UserLogin(BaseModel):
    email: EmailStr
    password: str
    


class UserOut(BaseModel):
    id: int
    email: EmailStr
    full_name: Optional[str] = None
    ram: Optional[List[Any]] = None
    domain: Optional[List[Any]] = None
    client_data: Optional[List[Any]] = None

    model_config = ConfigDict(from_attributes=True)