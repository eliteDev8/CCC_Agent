def extract_usage_from_openai(response: dict) -> dict:
    usage = response.get("usage", {})
    return {
        "prompt_tokens": usage.get("prompt_tokens", 0),
        "completion_tokens": usage.get("completion_tokens", 0),
        "total_tokens": usage.get("total_tokens", 0),
    }

def calculate_cost(total_tokens: int, model: str) -> float:
    rate = {
        "gpt-4o": 0.000005,
        "gpt-4": 0.00003,
        "gpt-3.5-turbo": 0.000002,
    }
    return total_tokens * rate.get(model, 0.000002)