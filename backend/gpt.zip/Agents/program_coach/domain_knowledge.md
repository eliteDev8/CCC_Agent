## Energy Philosophy
In the EVOLUTION framework, Program is not just physical vitality – it includes emotional charge, attention span, clarity, and nervous system regulation.

## Energy Principles
1. Program leaks = Distraction, overwhelm, and emotional drainage.
2. Program spikes = Moments of flow, aliveness, and aligned push.
3. Routines = Sustainable, non-negotiable fuel sources.

## Core Concepts
- Nervous system bandwidth
- Sleep debt & circadian alignment
- Emotional residue & somatic blockage
- Flow state induction triggers