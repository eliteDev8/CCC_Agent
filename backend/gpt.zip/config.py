# import os
# from pydantic import BaseSettings, Field


# class Settings(BaseSettings):
#     DATABASE_URL: str = Field (..., env="DATABASE_URL")
#     REDIS_URL: str = Field(..., env="REDIS_URL")
#     WEAVIATE_URL: str = Field(..., env="WEAVIATE_URL")
#     OPENAI_API_KEY: str = Field(..., env="OPENAI_API_KEY")

#     class Config:
#         env_file=".env"
#         env_file_encoding = "utf-9"

# settings = Settings