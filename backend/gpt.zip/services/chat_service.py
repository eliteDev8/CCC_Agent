from backend.engines.session_manager import SessionManager
from backend.engines.memory_engine.chat_history import ChatLogger
from backend.database import get_db_session
from backend.engines.memory_engine.embedding_handler import EmbeddingHandler
from backend.engines.memory_engine.prompt_composer import PromptComposer
from backend.models.user import User
from backend.engines.openai_client import OpenAIClient
from datetime import datetime

from backend.services.token_usage_service import log_token_usage, check_quota
from backend.utils.token_tracker import extract_usage_from_openai
from fastapi import Depends

from sqlalchemy.ext.asyncio import AsyncSession
import redis.asyncio as redis
import os
from fastapi import BackgroundTasks

# Setup Redis connection
redis_client: redis.Redis = redis.Redis(
    host=os.getenv("REDIS_HOST", "redis"),
    port=int(os.getenv("REDIS_PORT", 6379)),
    decode_responses=True
)

# Session manager uses redis
session_manager = SessionManager(redis_client, get_db_session())

composer = PromptComposer()
llm = OpenAIClient()

async def handle_user_message(
    session_id: str,
    message: str,
    db: AsyncSession = Depends(get_db_session),
    background_tasks: BackgroundTasks = None
) -> str:
    # 1. Load session info
    session_manager = SessionManager(redis_client, db)
    session_data = await session_manager.get_session(session_id)
    user_id = session_data.get("user_id")
    agent_key = session_data.get("agent_key")
    await check_quota(user_id=user_id, db=db)
    user = await db.get(User, user_id)
    # 2. Log user message
    logger = ChatLogger(db)
    retriever = await EmbeddingHandler().init()
    history = await logger.get_history(session_id)
    relevant_memory = retriever.search(user_id, message)
    prompt = await composer.compose(
        agent_key=agent_key,
        message=message,
        chat_history=history,
        memory=relevant_memory,
        user_blueprint={
            "ram": user.ram,
            "domain": user.domain,
            "client_data": user.client_data
        }
    )
    response = await llm.get_response(prompt)
    gpt_reply = response.choices[0].message.content
    usage_data = extract_usage_from_openai(response.model_dump())
    await log_token_usage(db, user_id=user_id, usage_data=usage_data, model=response.model)
    await logger.log(session_id, message+":"+gpt_reply, sender="user", timestamp=datetime.utcnow())
    if background_tasks:
        background_tasks.add_task(retriever.embed_and_store, user_id, message+":"+gpt_reply)
    return gpt_reply
    