from backend.models.token_usage import TokenUsage
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from fastapi import HTTPException

async def log_token_usage(db: AsyncSession, user_id: int, usage_data: dict, model: str):
    from backend.utils.token_tracker import calculate_cost
    cost = calculate_cost(usage_data["total_tokens"], model)

    usage = TokenUsage(
        user_id=user_id,
        prompt_tokens=usage_data["prompt_tokens"],
        completion_tokens=usage_data["completion_tokens"],
        total_tokens=usage_data["total_tokens"],
        cost=cost
    )
    db.add(usage)
    await db.commit()

async def check_quota(user_id: int, db: AsyncSession, max_monthly_tokens: int = 100000):
    from sqlalchemy import func
    from datetime import datetime

    month_start = datetime.utcnow().replace(day=1, hour=0, minute=0, second=0)
    result = await db.execute(
        select(func.sum(TokenUsage.total_tokens))
        .where(TokenUsage.user_id == user_id, TokenUsage.created_at >= month_start)
    )
    used = result.scalar() or 0
    if used >= max_monthly_tokens:
        raise HTTPException(status_code=403, detail="Monthly token quota exceeded.")