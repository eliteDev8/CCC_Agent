from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from backend.models.user import User
from backend.schemas.user import UserCreate
from backend.utils.security import hash_password, verify_password, create_access_token

async def register_user(data: UserCreate, db: AsyncSession):
    result = await db.execute(select(User).where(User.email == data.email))
    if result.scalar():
        raise ValueError("Email already registered")

    new_user = User(
        email=data.email,
        full_name=data.full_name,
        hashed_password=hash_password(data.password),
    )
    db.add(new_user)
    await db.commit()
    await db.refresh(new_user)
    return new_user

async def authenticate_user(email: str, password: str, db: AsyncSession):
    result = await db.execute(select(User).where(User.email == email))
    user = result.scalar()
    if not user or not verify_password(password, user.hashed_password):
        return None
    return user

async def create_token_for_user(user: User):
    return create_access_token(data={"sub": str(user.id)})



async def getUserData(email: str, db: AsyncSession):
    result = await db.execute(select(User).where(User.email == email))
    user = result.scalar()
    return user
