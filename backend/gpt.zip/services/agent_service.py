from datetime import datetime
from backend.engines.session_manager import SessionManager
from backend.engines.memory_engine.chat_history import ChatLogger
from backend.engines.memory_engine.embedding_handler import EmbeddingHandler
from backend.engines.openai_client import OpenAIClient
from backend.database import get_db_session

class AgentService:
    def __init__(self, db):
        self.session_mgr = SessionManager()
        self.logger = ChatLogger(get_db_session)
        self.retriever = EmbeddingHandler()
        self.llm = OpenAIClient()

    async def respond(self, session_id: str, user_msg: str):
        session = await self.session_mgr.get_session(session_id)
        await self.logger.log(session_id, user_msg, "user", datetime.utcnow())

        memory_snippets = await self.retriever.search(session["user_id"], user_msg)
        chat_history = await self.logger.get_history(session_id)

        full_prompt = "\n".join([
            "You're a helpful energy coach.",
            "Relevant memory:\n" + "\n".join(memory_snippets),
            "Chat so far:\n" + "\n".join(f"{m['sender']}: {m['message']}" for m in chat_history),
            f"User: {user_msg}",
            "Coach:"
        ])

        reply = await self.llm.get_response(full_prompt)
        await self.logger.log(session_id, reply, "agent", datetime.utcnow())

        return reply
