from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from backend.models.user import User
from fastapi import HTTPException
import copy

VALID_FIELDS = {"ram", "domain", "client_data"}

async def get_user_by_id(user_id: int, db: AsyncSession) -> User:
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

def update_json_array(items: list, key: str, new_value:str, action:str):
    items = copy.deepcopy(items) # ensure no shared reference issues

    if action == "add":
        if any(key in item for item in items):
            raise HTTPException(status_code=400, detail=f"Key '{key}' already exists in the array")
        items.append({key: new_value})
    elif action == "update":
        for item in items:
            if key in item:
                item[key] = new_value
                return items
        raise HTTPException(status_code=404, detail=f"Key '{key}' not found in the array")
    elif  action == "delete":
        new_items = [item for item in items if key not in item]
        if len(new_items) == len(items):
            raise HTTPException(status_code=404, detail=f"Key '{key}' not found in the array")
        return new_items
    return items

async def handle_json_field(user_id:int, field:str, db:AsyncSession):
    if field not in VALID_FIELDS:
        raise HTTPException(status_code=400, detail=f"Invalid field: {field}")
    user = await get_user_by_id(user_id, db)
    return user, getattr(user, field) or []