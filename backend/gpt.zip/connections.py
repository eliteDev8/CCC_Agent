import os
import redis.asyncio as redis
from backend.database import get_db_session
from backend.engines.session_manager import SessionManager

# Central Redis client
redis_client = redis.Redis(
    host=os.getenv("REDIS_HOST", "redis"),
    port=int(os.getenv("REDIS_PORT", 6379)),
    decode_responses=True
)

def get_redis_client():
    return redis_client

def get_session_manager(db=None):
    return SessionManager(redis_client, db or get_db_session())