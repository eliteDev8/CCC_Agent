
INSERT INTO agents (name, role, domain_focus, behavior_config, knowledge_paths, templates)
VALUES (
  'energy_coach',
  'Coach',
  'Energy',
  '{"strategy": "positive reinforcement"}',
  '["/docs/energy_basics.md"]',
  '{"welcome": "Hi, I''m your Energy Coach!"}'
)
ON CONFLICT (name) DO NOTHING;