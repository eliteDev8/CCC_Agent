# models/agent.py
from sqlalchemy import Column, Integer, String, JSON
from backend.database import Base

class Agent(Base):
    __tablename__ = "agents"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, nullable=False)
    role = Column(String, nullable=False)
    # domain_focus = Column(String, nullable=False)
    # behavior_config = Column(JSON, nullable=False)  # system_prompt, tone, persona
    # knowledge_paths = Column(JSON, nullable=True)   # paths to agent-specific content
    # templates = Column(JSON, nullable=True)         # linked conversational flows
