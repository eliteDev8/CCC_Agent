from sqlalchemy import Column, Integer, String, JSON
from backend.database import Base

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    full_name = Column(String, nullable=True)
    hashed_password = Column(String, nullable=False)

    ram = Column(JSON, nullable=True)  # User's RAM data
    domain = Column(JSON, nullable=True)  # User's domain data
    client_data = Column(JSON, nullable=True)  # User's client_data data