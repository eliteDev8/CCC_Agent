# backend/models/session.py

from sqlalchemy import Column, String, DateTime, Integer
from backend.database import Base
import datetime

class Session(Base):
    __tablename__ = "sessions"

    session_id = Column(String, primary_key=True)
    user_id = Column(Integer, nullable=False)
    agent_id = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
