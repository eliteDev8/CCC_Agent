from fastapi import FastAPI
from backend.models import user, agent, chat, session
from backend.api import agent, auth, chat, session, ram_field, client_field, domain_field, token
from backend.engines.memory_engine.embedding_handler import EmbeddingHandler

from backend.database import Base  # Your declarative base with models
from backend.database import engine  # Async SQLAlchemy engine you use in your project

app = FastAPI(title="GPT Agent Project")

app.include_router(agent.router)
app.include_router(auth.router)
app.include_router(chat.router)
app.include_router(session.router)
app.include_router(ram_field.router)
app.include_router(domain_field.router)
app.include_router(client_field.router)
app.include_router(token.router)

@app.on_event("startup")
async def on_startup():
    # app.state.embedding_handler = await EmbeddingHandler().init()
    # Create tables if they don't exist
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


@app.get("/health")
async def health_check():
    return {"status": "ok"}