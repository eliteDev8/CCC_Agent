from fastapi import Depends
import redis.asyncio as redis
from typing import AsyncGenerator

# Redis configuration
REDIS_URL = "redis://redis:6379"

# Create a Redis client instance
redis_client = redis.from_url(REDIS_URL, decode_responses=True)

# Dependency injection for FastAPI
async def get_redis() -> redis.Redis:
    return redis_client